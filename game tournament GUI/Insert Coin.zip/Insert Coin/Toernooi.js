function inschrijf(){
    window.location.href="inschrijf.html"
}